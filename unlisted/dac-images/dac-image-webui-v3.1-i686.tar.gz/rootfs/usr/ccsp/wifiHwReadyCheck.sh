#!/bin/sh

if [ ! -e "/sys/class/net/wl0" ]; then
    echo "$0: WiFi HW is not ready, stop ccspwifiagent.service !!"
    touch /tmp/wifi_initialized
    systemctl stop ccspwifiagent
    sleep 10
else
    echo "$0: completed successfully"
fi

