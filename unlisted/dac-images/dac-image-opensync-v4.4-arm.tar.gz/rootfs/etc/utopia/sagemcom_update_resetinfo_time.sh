#!/bin/sh

RDK_RESET_INFO_LOG=/rdklogs/logs/reset_info.txt

sleep 60
offset=$(date +%z)
hour_offset=${offset:0:3}

lastRebootReason="$(syscfg get X_RDKCENTRAL-COM_LastRebootReason)"
crash_line="* Crash date:"
grep -q "$crash_line" "$RDK_RESET_INFO_LOG"
if [ $? -eq 0 ]; then
    crash_time=$(awk '/Crash date:/{print $4,$5}' $RDK_RESET_INFO_LOG)
    correct_crash_time=$(date -d "$crash_time $hour_offset" +'%Y-%m-%d %H:%M:%S')
    sed -i "/* Crash date:/c* Crash date: $correct_crash_time" $RDK_RESET_INFO_LOG
    new_lastRebootReason="$lastRebootReason,$correct_crash_time"
    len=$(expr length "$new_lastRebootReason")
    if [ $len -le 64 ]; then
        syscfg set X_RDKCENTRAL-COM_LastRebootReason "$new_lastRebootReason"
    fi
fi

reboot_line="* Reboot request date:"
grep -q "$reboot_line" "$RDK_RESET_INFO_LOG"
if [ $? -eq 0 ]; then
    reboot_time=$(awk '/Reboot request date:/{print $5,$6}' $RDK_RESET_INFO_LOG)
    correct_reboot_time=$(date -d "$reboot_time $hour_offset" +'%Y-%m-%d %H:%M:%S')
    sed -i "/* Reboot request date:/c* Reboot request date: $correct_reboot_time" $RDK_RESET_INFO_LOG
    new_lastRebootReason="$lastRebootReason,$correct_reboot_time"
    len=$(expr length "$new_lastRebootReason")
    if [ $len -le 64 ]; then
        syscfg set X_RDKCENTRAL-COM_LastRebootReason "$new_lastRebootReason"
    fi
fi
