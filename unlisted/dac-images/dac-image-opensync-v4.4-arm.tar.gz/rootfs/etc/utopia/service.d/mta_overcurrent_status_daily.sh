#!/bin/sh
sh /usr/ccsp/mta/mta_overcurrentfault_status.sh &
