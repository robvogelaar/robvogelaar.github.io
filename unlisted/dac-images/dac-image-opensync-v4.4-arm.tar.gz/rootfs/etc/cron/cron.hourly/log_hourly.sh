#!/bin/sh
nice -n 19 sh /usr/ccsp/tad/log_hourly.sh &
