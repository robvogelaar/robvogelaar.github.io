#!/bin/sh
sysevent set ntpclient-restart
