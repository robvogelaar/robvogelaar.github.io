#!/bin/sh
source /etc/utopia/service.d/log_capture_path.sh

wait_for_cmcfg_initialized()
{
	while [ ! -e /tmp/cmcfgfile_finished ]
	do
		echo_t "wait for /tmp/cmcfgfile_finished====="
		sleep 5
	done

	echo_t "/tmp/cmcfgfile_finished created."
}

disable_virt_ni_hal()
{
	latticecli -n "set System.VirtNiHalEnable 0"
}

enable_virt_ni_hal()
{
	latticecli -n "set System.VirtNiHalEnable 1"
}

load_rtf()
{
	i=0
	wan_if=`syscfg get wan_physical_ifname`
	if [ $wan_if == "" ]; then
		echo_t "syscfg get wan_physical_ifname is empty, use erouter0 for wan interface for check bridge mode"
		wan_if="erouter0"
	fi	
	while true
	do
		echo_t "trueBridgeVirtNiHalSwitch [`date`] : load_rtf waitting for go into bridge mode..."
		i=`expr $i + 1`
		brctl show brlan0 | grep -w $wan_if
		if [ $? -eq 0 ]; then
			echo_t "it is bridge mode!"
			break
		fi
		if [ $i -gt 10 ]; then
			break
		fi		
		sleep 1
	done
	i=0
	while true
	do
		echo_t "trueBridgeVirtNiHalSwitch [`date`] : load_rtf waitting for llan0 up, need to delete it..."
		i=`expr $i + 1`
		brctl show brlan0 | grep llan0
		if [ $? -eq 0 ]; then
			brctl delif brlan0 llan0
			break
		fi
		if [ $i -gt 30 ]; then
			break
		fi
		echo_t [`date`]wait llan0 $i time
		sleep 1
	done
	ip addr add 192.168.0.1 dev brlan0
	modprobe rtf
	echo host_inf brlan0 > /proc/driver/rtf/cmd
	echo brcmtag_opcode uc 1 > /proc/driver/dqnet/cmd
	echo enable 1 > /proc/driver/rtf/cmd
	echo e 0 > /proc/driver/ethsw/vlan
}

wait_for_bridge_mode_correct()
{
	i=0
	wan_if=`syscfg get wan_physical_ifname`
	if [ $wan_if == "" ]; then
		echo_t "syscfg get wan_physical_ifname is empty, use erouter0 for wan interface for check bridge mode"
		wan_if="erouter0"
	fi	
	
	if [ "$(syscfg get last_erouter_mode)" == "0" ]; then
		while true
		do
			echo_t "trueBridgeVirtNiHalSwitch [`date`] : waitting for go into bridge mode..."	
			brctl show brlan0 | grep -w $wan_if
			if [ $? -eq 0 ]; then
				echo_t "it is bridge mode!"
				break
			fi
			i=`expr $i + 1`
			if [ $i -gt 30 ]; then
				break
			fi					
			sleep 1
		done
	else
		while true
		do
			echo_t "trueBridgeVirtNiHalSwitch [`date`] : waitting for go into router mode..."	
			brctl show brlan0 | grep -w $wan_if
			if [ $? -ne 0 ]; then
				echo_t "it is router mode!"
				break
			fi
			i=`expr $i + 1`
			if [ $i -gt 30 ]; then
				break
			fi					
			sleep 1
		done	
	fi	
}

# ------------------------------------ start --------------------------------------------

echo_t "==========trueBridgeVirtNiHalSwitch.sh in========="

while [ -e /tmp/trueBridge_virtNiHal_busy ]
do
	echo_t "trueBridge_virtNiHal_busy, wait..."
	sleep 1
done
touch /tmp/trueBridge_virtNiHal_busy

if [ ! -e /tmp/trueBridge_virtNiHal_initialized ]; then
	wait_for_cmcfg_initialized
	wait_for_bridge_mode_correct
fi

echo_t "check init stage over!!!"

if [ "$(syscfg get true_bridge_virtnihal_enable)" == "1" ] && [ "$(syscfg get last_erouter_mode)" == "0" ]; then
	echo_t "enable virtNiHalMode!!!"
	if [ "$(syscfg get last_virtnihal_mode)" != "1" ]; then
		syscfg set last_virtnihal_mode 1
		syscfg commit
	fi
	enable_virt_ni_hal
	if [ ! -e /tmp/trueBridge_rtf_initialized ]; then
		touch /tmp/trueBridge_rtf_initialized
		# only call it one time
		load_rtf
	fi
else
	if [ "$(syscfg get true_bridge_virtnihal_enable)" == "1" ];then
		syscfg set true_bridge_virtnihal_enable 0
		syscfg commit
	fi
	echo_t "disable virtNiHalMode!!!"
	disable_virt_ni_hal
fi

touch /tmp/trueBridge_virtNiHal_initialized
rm /tmp/trueBridge_virtNiHal_busy


