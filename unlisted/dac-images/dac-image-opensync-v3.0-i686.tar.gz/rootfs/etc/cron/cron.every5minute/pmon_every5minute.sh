#!/bin/sh
nice -n 19 sh /etc/utopia/service.d/pmon.sh
