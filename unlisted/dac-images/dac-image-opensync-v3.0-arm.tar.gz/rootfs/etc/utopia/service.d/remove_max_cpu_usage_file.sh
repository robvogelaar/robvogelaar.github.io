#!/bin/sh
/usr/ccsp/tad/remove_max_cpu_usage_file.sh
