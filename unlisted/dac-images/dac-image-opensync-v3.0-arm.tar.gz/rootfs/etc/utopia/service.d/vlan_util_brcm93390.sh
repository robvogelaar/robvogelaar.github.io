#!/bin/sh

#Configure LAN bridges using vlan_util (which calls vlan_hal)
VLAN_UTIL="vlan_util"
SYSEVENT="sysevent"
LOCKFILE=/var/tmp/vlan_util.pid
LOCKFD=/var/lock/managers.init.lock

#Initial state variable values (will get reset later)
IF_LIST=""
CURRENT_IF_LIST=""
USE_OVS_API=0
BRIDGE_MODE=`syscfg get bridge_mode`

#Moca home isolation information
MOCA_BRIDGE_IP="169.254.30.1"
LOCAL_MOCABR_UP_FILE="/tmp/MoCABridge_up"
HOME_LAN_ISOLATION=`psmcli get dmsb.l2net.HomeNetworkIsolation`

#GRE tunnel information
DEFAULT_GRE_TUNNEL="gretap0"

#Dummy MAC address to assign to GRE tunnels so we can add them to bridges
DUMMY_MAC="02:03:DE:AD:BE:EF"

#Instance maps to brlan0, brlan1, etc.
INSTANCE="$2"

wait_for_gre_ready(){
    while [ "`$SYSEVENT get if_${LAN_GRE_TUNNEL}-status`" != "ready" ] ; do
        echo "Waiting for $LAN_GRE_TUNNEL to be ready..."
        sleep 1
    done
}
wait_for_erouter0_ready(){
    while [ "`$SYSEVENT get wan-status`" != "started" ] ; do
        echo "Waiting for erouter0 to be ready..."
        sleep 1
    done
}

# use ovs APIs for the LAN bridge if the CPE is not in bridge mode and emf is disabled
if [ "$BRIDGE_MODE" = "0" ] && [ "$INSTANCE" = "1" ] && [ "`nvram get emf_enable`" != "1" ]; then
    USE_OVS_API=1
fi

local_add_if() {
    if [ "$USE_OVS_API" = "1" ]; then
        # TODO: VLAN
        ovs-vsctl add-port "$1" "$2"

        # LGI hack:
        # Here we are adding an IPv6 flowmgr entry to enable all multicast reception (using flowmgr bug as a feature) 
        # Hardcoded wl0 is not an issue either as multicast will be processed in software and will be sent on the correct interface(s)
        echo mdb_add lbr0 wl0 ff38:: > /proc/driver/flowmgr/cmd
    else
        $VLAN_UTIL add_interface "$1" "$2" "$3"
    fi
}

local_del_if() {
    if [ "$USE_OVS_API" = "1" ]; then
        ovs-vsctl del-port "$1" "$2"
    else
        $VLAN_UTIL del_interface "$1" "$2"
    fi
}

#Do any gretap setup needed here, or call events, whatever
#Also returns LAN_GRE_TUNNEL so we know which to use for the base tunnel
#Syntax: setup_gretap [start|stop] bridge_name group_number
setup_gretap(){
    GRE_MODE="$1"
    LAN="$2"
    LAN_VLAN="$3"

    #For now, both use the same tunnel
    LAN_GRE_TUNNEL="$DEFAULT_GRE_TUNNEL"

    if [ "$GRE_MODE" = "start" ]
    then
        #Wait until gre got created
        wait_for_gre_ready
        vconfig add $LAN_GRE_TUNNEL $LAN_VLAN
        ifconfig $LAN_GRE_TUNNEL up
        ifconfig ${LAN_GRE_TUNNEL}.$LAN_VLAN up
    else
        vconfig rem ${LAN_GRE_TUNNEL}.${LAN_VLAN}
    fi
}

#Update the list of active multinet instances
update_instances(){
    INSTANCES=`sysevent get multinet-instances`

    echo "got instances $INSTANCES"

    if [ "$1" = "start" ] ; then
        #Add to list of instances
        NEWINST="$INSTANCES"
        FOUND=0
        for MYINST in $INSTANCES
        do
            if [ "$MYINST" = "$INSTANCE" ] ; then
                FOUND=1
            fi
        done
        if [ $FOUND -eq 0 ] ; then
            if [ "$NEWINST" = "" ] ; then
                NEWINST="$INSTANCE"
            else
                NEWINST="$NEWINST $INSTANCE"
            fi
        fi
    else
        #Remove from list of instances
        NEWINST=""
        for MYINST in $INSTANCES
        do
            if [ "$MYINST" != "$INSTANCE" ] ; then
                if [ "$NEWINST" = "" ] ; then
                    NEWINST="$MYINST"
                else
                    NEWINST="$NEWINST $MYINST"
                fi
            fi
        done
    fi

    sysevent set multinet-instances "$NEWINST"
}

#Gets a space-separated list of interfaces currently in a group
#Returns the list in CURRENT_IF_LIST
get_current_if_list() {
    if [ "$USE_OVS_API" = "1" ]; then
        CURRENT_IF_NAMES=`ovs-vsctl list-ports "$BRIDGE_NAME" | grep -v "^$BRIDGE_NAME" | grep -v "^pgd"`
    else
        CURRENT_IF_NAMES=`$VLAN_UTIL list_interfaces "$BRIDGE_NAME"`
    fi
    CMD_STATUS=$?
    CURRENT_IF_LIST=""

    if [ $CMD_STATUS -ne 0 ]
    then
        echo "$0 error: couldn't get interface list for group $BRIDGE_VLAN"
    else
        for LINE in $CURRENT_IF_NAMES; do
            if [ "$CURRENT_IF_LIST" = "" ]
            then
                CURRENT_IF_LIST="$LINE"
            else
                CURRENT_IF_LIST="$CURRENT_IF_LIST $LINE"
            fi
        done
    fi
    echo -e "Group $BRIDGE_NAME vlan $BRIDGE_VLAN now includes:\t$CURRENT_IF_LIST"
}

#Calls dmcli to check whether switch port 2 should be enabled in instance 1 (private LAN) or 2 (XFinity Home) networks
#If the setting is not yet available, waits for 1 second and tries again, for up to 30 seconds
#Returns "true" in variable $isport2enable if port 2 should be enabled in this group
check_port_2(){
    COUNTER=0
    MAXTRIES=30

    #Only supports instance 1 or 2 currently
    case $INSTANCE in
        #XFinity Private LAN
        1)
            PORT_CMD="dmcli eRT getv Device.Bridging.Bridge.1.Port.8.Enable"
        ;;
        #XFinity Home
        2)
            PORT_CMD="dmcli eRT getv Device.Bridging.Bridge.2.Port.2.Enable"
        ;;
    esac

    while [ $COUNTER -lt $MAXTRIES ] ; do
        PORT_CHECK=`$PORT_CMD | grep value | cut -f3 -d : | cut -f2 -d " "`
        if [ -z "$PORT_CHECK" ] ; then
            echo "Waiting for dmcli port 2 configuration to be available..."
            COUNTER=`expr $COUNTER + 1`
            isport2enable="false"
            sleep 1
        else
            isport2enable="$PORT_CHECK"
            break
        fi
    done
}

# Check if WiFi is enabled 
check_xfinity_wifi(){
    #Only supports instance 1 or 2 currently
    XFINITY_WIFI_CHECK_CMD="dmcli eRT getv Device.DeviceInfo.X_COMCAST_COM_xfinitywifiEnable"
    XFINITY_WIFI_ENABLE=`$XFINITY_WIFI_CHECK_CMD`

    echo "CHECKING XFINITY WIFI"
    isXfinityWiFiEnable=`echo "$XFINITY_WIFI_ENABLE" | grep value | cut -f3 -d : | cut -f2 -d " "`
}

wait_for_ovs_to_end(){
        if [ "$USE_OVS_API" != "1" ]; then
             while [ -d "/sys/devices/virtual/net/ovs-system/" ]; do
                     sleep 1
             done
        fi
}

#Returns a space-separated list of interfaces that should be in this group in the current operating mode
#Returns the list in IF_LIST
get_expected_if_list() {

    IF_LIST_ALL=""
    IF_LIST=""
    case $INSTANCE in

        #XFinity Private LAN
        1)
            IF_LIST_ALL="$(psmcli get dmsb.l2net.$INSTANCE.Members.Eth)"
            if [ "$BRIDGE_MODE" = "0" ] && [ "$HOME_LAN_ISOLATION" != "1" ]; then
                IF_LIST_ALL+=" moca0"
            fi
            check_port_2
            if [ "$isport2enable" = "true" ]; then
                IF_LIST_ALL+=" eth1"
            fi
            if [ "$BRIDGE_MODE" -gt 0 ]; then
                wait_for_ovs_to_end
                IF_LIST_ALL+=" l${CMDIAG_IF} erouter0"
            fi
            if [ "`$SYSEVENT get reboot-triggered`" != "1" ]; then
                wifi_lan_ifs=`nvram get lan_ifnames`
                IF_LIST_ALL+=" $wifi_lan_ifs"
            fi
        ;;

        #XFinity Home
        2)
            check_port_2
            if [ "$isport2enable" = "true" ]; then
                IF_LIST_ALL="eth1"
            fi
            if [ "`$SYSEVENT get reboot-triggered`" != "1" ]; then
                wifi_lan1_ifs=`nvram get lan1_ifnames`
                IF_LIST_ALL+=" $wifi_lan1_ifs"
            fi
        ;;

        #XFinity Hostspot 2.4 GHz
        3)
            check_xfinity_wifi
            if [ "$isXfinityWiFiEnable" = "true" ]; then
                IF_LIST_ALL="${DEFAULT_GRE_TUNNEL}.${BRIDGE_VLAN}"
            fi
        ;;

        #XFinity Hotspot 5 GHz
        4)
            check_xfinity_wifi
            if [ "$isXfinityWiFiEnable" = "true" ]
            then
                IF_LIST_ALL="${DEFAULT_GRE_TUNNEL}.${BRIDGE_VLAN}"
            fi
        ;;

        #Guest Network
        5)
            IF_LIST_ALL="$(psmcli get dmsb.l2net.$INSTANCE.Members.WiFi)"
        ;;

        #XFinity IoT network
        6)
            IF_LIST_ALL="$(psmcli get dmsb.l2net.$INSTANCE.Members.WiFi)"
        ;;

        #Home Network Isolation
        9)
            if [ "$HOME_LAN_ISOLATION" = "1" ] ; then
                IF_LIST_ALL="moca0"
            fi
        ;;

    esac

    # Update IF_LIST with the existing interface only
    for if_single in $IF_LIST_ALL
    do
        if [ -e "/sys/class/net/$if_single" ]; then
            IF_LIST+="$if_single "
        fi
    done

    # Update LAN interfaces list for XFinity Private LAN
    if [ "$INSTANCE" = "1" ]; then
        # Set IF_LIST with the existing interfaces
        syscfg set lan_ethernet_physical_ifnames "$IF_LIST"
    fi

    echo -e "Group $BRIDGE_NAME vlan $BRIDGE_VLAN should include:\t$IF_LIST"
}

remove_from_group() {
    IF_TO_REMOVE="$1"

    echo "Removing $IF_TO_REMOVE from group $BRIDGE_NAME"

    if [ "`echo \"$IF_TO_REMOVE\"|egrep -e \"${DEFAULT_GRE_TUNNEL}*\"`" != "" ]
    then
        setup_gretap stop $BRIDGE_NAME $BRIDGE_VLAN
    fi

    local_del_if $BRIDGE_NAME $IF_TO_REMOVE
}

remove_from_all_groups(){
    IF_TO_REMOVE="$1"

    $VLAN_UTIL show | awk 'NF>1 && NR>1 {print $1}' |while read GROUP_NAME
    do
        $VLAN_UTIL list_interfaces $GROUP_NAME|while read IF_FOUND
        do
            if [ "$IF_TO_REMOVE" = "$IF_FOUND" -a "$GROUP_NAME" != "$BRIDGE_NAME" ]
            then
                echo "$IF_TO_REMOVE already belongs to $GROUP_NAME, removing"
                local_del_if $GROUP_NAME $IF_FOUND
                break
            fi
        done
    done
}

add_to_group() {
    IF_TO_ADD="$1"
    VLAN_TO_ADD=""

    #If this interface is already in another group, remove it from there
    remove_from_all_groups $IF_TO_ADD $VLAN_TO_ADD

    #Check if the interface desired is a vlan interface
    echo "$IF_TO_ADD"|egrep -e ".*\..*"
    if [ $? -eq 0 ]
    then
        VLAN_TO_ADD="`echo \"$IF_TO_ADD\"|cut -d \".\" -f 2`"
        BASE_IF="`echo \"$IF_TO_ADD\"|cut -d \".\" -f 1`"
        IF_TO_ADD="$BASE_IF"
        echo "Adding ${IF_TO_ADD}.${VLAN_TO_ADD} to group $BRIDGE_NAME"
    else
        echo "Adding $IF_TO_ADD to group $BRIDGE_NAME"
    fi

   if [ "`echo \"$IF_TO_ADD\"|egrep -e \"${DEFAULT_GRE_TUNNEL}*\"`" != "" ]
    then
    check_xfinity_wifi
    if [ "$isXfinityWiFiEnable" = "true" ]
        then
            echo "Xfinity wifi enabled"
            echo "Xfinity wifi enabled"
            wait_for_erouter0_ready
        fi
    fi

    echo " Bringing $IF_TO_ADD is up "
    ifconfig $IF_TO_ADD up
    local_add_if $BRIDGE_NAME $IF_TO_ADD $VLAN_TO_ADD
}

#This function will create the group if it doesn't already exist,
#remove interfaces that shouldn't be connected, and add any
#interfaces that should be connected to this group.
#Takes a parameter "true" or "false" which controls whether we should
#update the multinet status.  Defaults to "true".
sync_group_settings() {
    RAISE_EVENTS="$1"

    [ "$RAISE_EVENTS" != "false" ] && $SYSEVENT set multinet_${INSTANCE}-localready 1

    # Check if bridge exists. If not, create it.
    # Need to revisit this, when we need to support VLAN filtering in this virutal bridge.
    # For now, the exsiting vlan_util doesn't support vlan configuration on the bridge itself.
    if [ "$USE_OVS_API" = "1" ]; then
        BRIDGE_EXIST=`flock $LOCKFD ovs-vsctl list-br | grep -w $BRIDGE_NAME`
    else
        BRIDGE_EXIST=`$VLAN_UTIL show | grep -w $BRIDGE_NAME`
    fi
    #CURRENT_VLAN=`$VLAN_UTIL show $BRIDGE_NAME`
    #CMD_STATUS=$?
    #if [ $CMD_STATUS -ne 0 -o "$CURRENT_VLAN" != "$BRIDGE_VLAN" ]

    brlan0_status=`ifconfig brlan0 |sed -n "4p"|awk '{print $1}'`
    if [ -z "$BRIDGE_EXIST" ]
    then
        echo "Group $BRIDGE_NAME doesn't exist, creating it"
        #echo "Group $BRIDGE_NAME doesn't exist or has wrong VLAN ID, re-creating"
        #We need to destroy and re-create bridge
        #ifconfig $BRIDGE_NAME down
        #$VLAN_UTIL del_group $BRIDGE_NAME
        #$VLAN_UTIL add_group $BRIDGE_NAME $BRIDGE_VLAN
        echo "Bringing up $BRIDGE_NAME"
        if [ "$USE_OVS_API" = "1" ]; then
            if [ -n "$($VLAN_UTIL show | grep -w $BRIDGE_NAME)" ]; then
                ifconfig $BRIDGE_NAME down
                $VLAN_UTIL del_group $BRIDGE_NAME
            fi
            /usr/opensync/scripts/opensync.init ovs-init
        else
            BRIDGE_EXIST=`flock $LOCKFD ovs-vsctl list-br | grep -w $BRIDGE_NAME`
            if [ -n "$BRIDGE_EXIST" ]; then
                /usr/opensync/scripts/opensync.init ovs-suspend
                wait_for_ovs_to_end
            fi
            $VLAN_UTIL add_group $BRIDGE_NAME $BRIDGE_VLAN
        fi
        ifconfig $BRIDGE_NAME up
        if [ $BRIDGE_NAME = "brlan0" ]; then
            psmcli set "dmsb.l2net.$INSTANCE.Members.Eth" "eth0 eth2 eth3 eth4 eth5 eth6 eth7 stb0"
        fi
    else
        if [ $BRIDGE_NAME = "brlan0" ] && [ $brlan0_status != "UP" ] && [ $MODE = "up" ]
        then
            echo "Group $BRIDGE_NAME exist, bringing it UP"
            ifconfig $BRIDGE_NAME up
        else
           if [ $BRIDGE_NAME = "brlan7" ] && [ $MODE = "up" ]
           then
               brlan7_status=`ifconfig brlan7 |sed -n "4p"|awk '{print $1}'`
               if [ $brlan7_status != "UP" ]
               then
                   echo "Group $BRIDGE_NAME exist, bringing it UP"
                   ifconfig $BRIDGE_NAME up
               fi
           fi 
        fi
    fi

    stp_enable=$(syscfg get stp_enable)

    if [ "$stp_enable" = "true" ]; then
        brctl stp brlan0 on
    fi

    [ "$RAISE_EVENTS" != "false" ] && $SYSEVENT set multinet_${INSTANCE}-status partial

    (
    flock 200
    #Get the list of which interfaces should be added to this group
    get_expected_if_list

    #Remove any interfaces that don't belong in this group
    get_current_if_list
    for EXISTING_IF in $CURRENT_IF_LIST; do
        IF_BELONGS=0
        for EXPECTED_IF in $IF_LIST; do
            if [ "$EXISTING_IF" = "$EXPECTED_IF" ]
            then
                IF_BELONGS=1
            fi
        done

        if [ $IF_BELONGS -eq 0 ]
        then
            remove_from_group $EXISTING_IF
        fi
    done

    #Now add whatever is missing to this group
    get_current_if_list
    for NEEDED_IF in $IF_LIST; do
        IF_FOUND=0
        for EXISTING_IF in $CURRENT_IF_LIST; do
            if [ "$EXISTING_IF" = "$NEEDED_IF" ]
            then
                IF_FOUND=1
            fi
        done

        if [ $IF_FOUND -ne 1 ]
        then
            add_to_group $NEEDED_IF
        fi
    done

    flock -u 200
    )200>${LOCKFD}

    #In bridge mode if we reconfigure the ports we need to flush DOCSIS CPE table
     if [ $BRIDGE_MODE -gt 0 ]
     then
         # SANG Brcm needs to provide rpc calls to flush DOCSIS CPE table
        # ncpu_exec -e "(echo \"LearnFrom=CPE_DYNAMIC\" > /proc/net/dbrctl/delalt)"
        echo  "Flush CPE table"
     fi

     #Don't set brlan0 status ready in bridge mode
     if [ "$BRIDGE_MODE" = "0" ] || [ "$INSTANCE" != "1" ]; then
        [ "$RAISE_EVENTS" != "false" ] && $SYSEVENT set multinet_${INSTANCE}-status ready
     fi
}
    EMTA_STANDALONE_MODE=`syscfg get emta_standalone_mode`
    if [ "$EMTA_STANDALONE_MODE" = "1" ]
    then
        echo  "doing vlan bridge things............."
        ip link add name vethpriv type veth peer name vethwan
        brctl addif brlan0 vethwan
        brctl addif privbr vethpriv
        ifconfig vethwan up
        ifconfig vethpriv up
        echo 1 > /sys/class/net/brlan0/bridge/flush
    fi

#Remove any interfaces from this group
remove_all_from_group() {
    IF_LIST=""
    sync_group_settings false
}

print_syntax(){
    echo "Syntax: $0 [multinet-up|multinet-down|multinet-syncMembers] instance"
    echo -e "\t$0 [iot-up|iot-down]"
}

#Script execution begins here
while [ -e ${LOCKFILE} ] ; do
    #See if process is still running
    kill -0 `cat ${LOCKFILE}`
    if [ $? -ne 0 ]
    then
        break
    fi
    echo "Waiting for parallel instance of $0 to finish..."
    sleep 1
done

#make sure the lockfile is removed when we exit and then claim it
trap "rm -f ${LOCKFILE}; exit" INT TERM EXIT
echo $$ > ${LOCKFILE}

CMDIAG_IF=`syscfg get cmdiag_ifname`

#Get event
EVENT="$1"
if [ "$EVENT" = "multinet-up" ]
then
    MODE="up"
elif [ "$EVENT" = "multinet-start" ]
then
    MODE="start"
elif [ "$EVENT" = "multinet-restart" ]
then
    MODE="restart"
elif [ "$EVENT" = "lnf-setup" ]
then
    MODE="lnf-start"
elif [ "$EVENT" = "lnf-down" ]
then
    MODE="lnf-stop"
elif [ "$EVENT" = "multinet-down" ]
then
    MODE="stop"
elif [ "$EVENT" = "multinet-stop" ]
then
    MODE="stop"
elif [ "$EVENT" = "multinet-syncMembers" ]
then
    MODE="syncmembers"
else
    echo "$0 error: Unknown event: $1"
    print_syntax
    rm -f ${LOCKFILE}
    exit 1
fi

#remove the support of brlan1
if [ "${INSTANCE}" == "2" ]; then
    echo "brlan1 is not supported"
    rm -f ${LOCKFILE}
    exit 1
fi

#Get lan bridge name from instance number
BRIDGE_NAME=""
BRIDGE_VLAN=0
case $INSTANCE in
    1)
        #Private LAN
        BRIDGE_NAME="brlan0"
        BRIDGE_VLAN=100
    ;;
    2)
        #Home LAN
        BRIDGE_NAME="brlan1"
        BRIDGE_VLAN=101
    ;;
    5)
        #Guest Network
        BRIDGE_NAME="brlan7"
        BRIDGE_VLAN=107
    ;;
    6)
        BRIDGE_NAME="br106"
        BRIDGE_VLAN=106
    ;;
    9)
        #Home Network Isolation
        BRIDGE_NAME="brlan10"
        BRIDGE_VLAN=111
    ;;
    *)
        #Unknown / unsupported instance number
        echo "$0 error: Unknown instance $INSTANCE"
        print_syntax
        rm -f ${LOCKFILE}
        exit 1
    ;;
esac

#Set the interface name
$SYSEVENT set multinet_${INSTANCE}-name $BRIDGE_NAME
$SYSEVENT set multinet_${INSTANCE}-vid $BRIDGE_VLAN

if [ "$MODE" = "up" ]
then
    remove_all_from_group
    #Sync the group interfaces and raise status events
    sync_group_settings

    #Update active instances
    update_instances start

    #Home Network Isolation
    if [ $BRIDGE_NAME = "brlan10" ] && [ "$HOME_LAN_ISOLATION" -eq 1 ]
    then
        ip link set brlan10 allmulticast on
        ifconfig brlan10 $MOCA_BRIDGE_IP
        ip link set brlan10 up
        echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts
        sysctl -w net.ipv4.conf.all.arp_announce=3
        ip rule add from all iif brlan10 lookup all_lans
        ip rule add from all iif brlan0 lookup moca

        #Disabling rp_filter
        echo 0 > /proc/sys/net/ipv4/conf/all/rp_filter
        echo 0 > /proc/sys/net/ipv4/conf/brlan0/rp_filter
        echo 0 > /proc/sys/net/ipv4/conf/brlan10/rp_filter

        #Move moca to a different netdev_group
        echo 3 > /sys/class/net/moca0/netdev_group

        touch $LOCAL_MOCABR_UP_FILE
    fi
elif [ $MODE = "start" ]
then
    remove_all_from_group
    #Sync the group interfaces and raise status events
    sync_group_settings

    #Update active instances
    update_instances start

    #Restart the firewall after the network is set up
    echo "VLAN : Triggering RDKB_FIREWALL_RESTART from mode=start"
    $SYSEVENT set firewall-restart
elif [ $MODE = "lnf-start" ]
then
    remove_all_from_group
    #Sync the group interfaces and raise status events
    sync_group_settings

    ifconfig $BRIDGE_NAME 192.168.106.254
    #Restart the firewall after setting up LnF
    echo "VLAN : Triggering RDKB_FIREWALL_RESTART from mode=Lnfstart"
    $SYSEVENT set firewall-restart
elif [ $MODE = "lnf-stop" ]
then
    remove_all_from_group
    echo "VLAN : Triggering RDKB_FIREWALL_RESTART from mode=Lnfstop"
    $SYSEVENT set firewall-restart
elif [ "$MODE" = "stop" ]
then
    #Indicate LAN is stopping
    $SYSEVENT set multinet_${INSTANCE}-status stopping
    remove_all_from_group

    if [ $BRIDGE_NAME = "brlan10" ]; then
        ip link set brlan10 down
        brctl delbr brlan10

        #Move moca back to original netdev_group
        echo 1 > /sys/class/net/moca0/netdev_group
    fi

    #Send event that LAN is stopped
    $SYSEVENT set multinet_${INSTANCE}-status stopped

    #Update active instances
    update_instances stop
elif [ "$MODE" = "syncmembers" ]
then
    #Sync the group interfaces and raise status events
    sync_group_settings
elif [ "$MODE" = "restart" ]
then
    #Indicate LAN is restarting
    $SYSEVENT set multinet_${INSTANCE}-status restarting
    remove_all_from_group
    #Sync the group interfaces and raise status events
    sync_group_settings

    #Update active instances
    update_instances start

    #Restart the firewall after the network is set up
    echo "VLAN : Triggering RDKB_FIREWALL_RESTART from mode=restart"
    $SYSEVENT set firewall-restart
else
    echo "Syntax: $0 [start | stop | restart]"
    rm -f ${LOCKFILE}
    exit 1
fi

# Enable telnetd access, ctrl+o in Ecos can switch console to RG
    telnetd -l /bin/sh -K
    iptables -I INPUT -i brlan0 -p tcp --dport 23 -j ACCEPT
    iptables -I INPUT -i brlan0 -p tcp --dport 22 -j ACCEPT
    ushd -d

# Update LAN bridge MAC address
#ROUTER_PERM_CONFIG=/data/router-perm.config
#if [ -f "$ROUTER_PERM_CONFIG" ]; then
#    LAN_BRIDGE_MAC=$(grep LanBridgeMacAddress $ROUTER_PERM_CONFIG | sed "s|<[/]*LanBridgeMacAddress>||g")
#    if [ "$LAN_BRIDGE_MAC" != "(null)" ] && [ -e "/sys/class/net/brlan0" ]; then
#        ifconfig brlan0 hw ether $LAN_BRIDGE_MAC || true
#    fi
#fi

# Update LAN bridge MAC address
DECODE_SAGEM_FACTORY_CFG=/tmp/.mdm_factory.cfg
if [ ! -f "$DECODE_SAGEM_FACTORY_CFG" ]; then
    mdmfiledecode
    sleep 1
fi
if [ -f "$DECODE_SAGEM_FACTORY_CFG" ]; then
    LAN_BRIDGE_MAC=$(grep LanIpMacAddress $DECODE_SAGEM_FACTORY_CFG | sed "s|<[/]*LanIpMacAddress>||g" |sed "s|[[:space:]]||g")
    if [ "$LAN_BRIDGE_MAC" != "(null)" ] && [ -e "/sys/class/net/brlan0" ]; then
        ifconfig brlan0 hw ether $LAN_BRIDGE_MAC || true
    fi
#rm $DECODE_SAGEM_FACTORY_CFG
fi

# Enable Broadcom WiFi packet Acceleration
for wlmainindex in {0..1}
do
    if [ -e "/sys/class/net/wl${wlmainindex}" ]; then
        echo 3 > /sys/class/net/wl${wlmainindex}/queues/rx-0/rps_cpus
        echo 3 > /sys/class/net/wl${wlmainindex}/queues/tx-0/xps_cpus
        echo 1 > /sys/class/net/wl${wlmainindex}/netdev_group
        echo "inf add wl${wlmainindex}" > /proc/driver/flowmgr/cmd
    fi
done

# Enable telnetd access
telnet_en=`nvram get telnet_enable`
if [ "${telnet_en}" == "1" ]; then
    telnetd -l /bin/sh -K
    iptables -I INPUT -i brlan0 -p tcp --dport 23 -j ACCEPT
    iptables -I INPUT -i brlan0 -p tcp --dport 22 -j ACCEPT
    ushd -d
fi

#For Factory test, enable ssh even no WAN IP
sysevent set sshd-restart

#Script finished, remove lock file
rm -f ${LOCKFILE}
