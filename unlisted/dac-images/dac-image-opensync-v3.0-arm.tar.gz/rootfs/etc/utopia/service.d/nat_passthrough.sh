#!/bin/sh

#NAT passthrough ,MNG 

bridge_mode="$(syscfg get bridge_mode)"
natPassthrough_enable="$(syscfg get natPassthrough_enable)"
wan_mac="$(syscfg get base_mac_address)"
wan_name="erouter0"
nat_passthrough_if_name="lbr0"
nat_passthrough_if_MAC="02:10:18:33:22:11"

install_macpt_driver()
{
    if [ ! -d /proc/driver/macpt/ ]; then
        modprobe macpt
    fi
}

add_macpt_to_bridge()
{
    if [ ! -d /sys/class/net/erouter0/bridge/ ] || [ ! -d /proc/driver/macpt/ ]; then
        echo "ERROR: bridge erouter0 doesn't exists"
        return 1
    else
        if [ -d /sys/class/net/macpt/brport ]; then
            echo "WARNING: interface macpt is already in a bridge"
        else
            ifconfig macpt hw ether 00:00:00:11:22:33
            ifconfig macpt up
            # connect macpt interface to erouter0 bridge.
            brctl addif erouter0 macpt
        fi
    fi
    return 0
}

operate_mac_to_db()
{
    total_client_count="$(syscfg get mngFWNATPassthroughCount)"
    [ -n "$total_client_count" ] || total_client_count=0
    if [ "$total_client_count" != 0 ]; then
        for i in $(seq 1 $total_client_count); do
            name=$(syscfg get "mngFWNATPassthrough_$i")
            if [ -z "$name" ]; then
                echo "WARNING: NAT Passthrough client index $i has no name"
                continue
            fi

            mac=$(syscfg get "$name" mac)
            if [ -z "$mac" ]; then
                echo "WARNING: NAT Passthrough client $name has no configured MAC address"
                continue
            fi
            if [ ! -d /proc/driver/macpt/ ]; then
                echo "ERROR: macpt driver doesn't install"
                return 1
            else
                if [ "$(syscfg get "$name" enable)" = "1" ] && [ "$natPassthrough_enable" != 0 ] && [ "$bridge_mode" = "0" ]; then
                    echo del $mac > /proc/driver/macpt/mac
                    echo add $mac > /proc/driver/macpt/mac
                else
                    echo del $mac > /proc/driver/macpt/mac
                fi
            fi
            let i++
        done
        unset i name enable
    fi
}

check_bridge()
{
    if [ "$bridge_mode" = 0 ] ; then
        if [ ! -d /sys/class/net/${wan_name}/bridge/ ]; then
            # rebuild bridge
            if [ -d /sys/class/net/${wan_name}/brport ]; then
                brctl delif brlan0 ${wan_name}
            fi
            if [ -d /sys/devices/virtual/net/ovs-system/lower_${wan_name} ]; then
                ovs-vsctl del-port brlan0 ${wan_name}
            fi
            ip addr flush ${wan_name}
            ip link set ${wan_name} down
            ip link set ${wan_name} name ${nat_passthrough_if_name}
            ifconfig  ${nat_passthrough_if_name} hw ether ${nat_passthrough_if_MAC}
            brctl addbr ${wan_name} 
            ifconfig ${wan_name} hw ether ${wan_mac}
            brctl addif ${wan_name} ${nat_passthrough_if_name}
            ifconfig ${wan_name} up
            ifconfig ${nat_passthrough_if_name} up
        fi
    else 
        if [ -d /sys/class/net/${wan_name}/bridge/ ]; then
            # rebuild bridge
            service_stop
            ip link set ${nat_passthrough_if_name} down
            ip link set ${wan_name} down
            brctl delif ${wan_name} ${nat_passthrough_if_name}
            brctl delbr ${wan_name} 
            ip link set ${nat_passthrough_if_name} name ${wan_name} 
            ifconfig   ${wan_name}  hw ether ${wan_mac}
            if [ ! -d /sys/class/net/${wan_name}/brport ]; then
               brctl addif brlan0 ${wan_name}
            fi
            ip link set ${wan_name} up
        fi
    fi

}

service_start()
{
    echo "*** Starting MNG NAT Passthrough $bridge_mode***"
    if [ "$bridge_mode" != 0 ]; then
        echo "*** bridge_mode  return 0***"
        # nothing to do
        return 0
    fi

    install_macpt_driver
    add_macpt_to_bridge
    operate_mac_to_db
}

service_stop()
{
    echo "*** Stopping MNG NAT Passthrough ***"
    if [ "$bridge_mode" != "0" ] || [ "$natPassthrough_enable" = 0 ]; then
        operate_mac_to_db
    fi

    # If not in bridge mode then delete macpt interface from the bridge
    if [ -d /sys/class/net/macpt/brport ]; then
        brctl delif ${wan_name} macpt
        ip link set macpt down
    fi
}

service_reload()
{
    check_bridge
    if [ "$bridge_mode" != "0" ] || [ "$natPassthrough_enable" = 0 ]; then
        # bridge mode and NAT Passthrough don't coexist, if we're restarting
        # and bridge mode is on, disable this service.
        # Drop stderr because if NPT never started, service_stop will print
        # errors about deleting nonexistent things
        service_stop 2>/dev/null
        return 0
    fi

    service_start
}

case "$1" in
    start|restart)
        # start and restart are really the same thing. service_reload
        # will call service_start (or maybe even service_stop) if necessary
        service_reload
        ;;
    stop)
        service_stop
        ;;

    # full-start and full-restart are for debugging only!
    # Don't call these from other code
    full-start)
        service_start
        ;;
    full-restart)
        service_stop && service_start
        ;;
    *)
        echo "Usage: $0 [ start | stop | restart ]"
        exit 3
        ;;
esac
