#! /bin/sh

sleep 5

RDK_RESET_INFO_LOG=/rdklogs/logs/reset_info.txt
RDK_BOOT_TIME_LOG=/rdklogs/logs/BootTime.log
if echo "$(cat /proc/device-tree/bolt/reset-list)" | grep -q "power_on"; then
    if [ -f "$RDK_RESET_INFO_LOG" ]; then
        if [ -f "$RDK_BOOT_TIME_LOG" ]; then
            waninit_start_line="Waninit_start"
            grep -q "$waninit_start_line" "$RDK_BOOT_TIME_LOG"
            if [ $? -eq 0 ]; then
                ##########Calculate the true power on time##########
                hour_str=$(awk '/Waninit_start=/{print $1}' $RDK_BOOT_TIME_LOG)
                second_str=$(echo $(awk '/Waninit_start=/{print $3}' $RDK_BOOT_TIME_LOG) | cut -d= -f2)
                Tmp_date=$(date +"%Y-%m-%d")
                time_stamp=$(date --date="$Tmp_date $hour_str" +%s)
                power_on_time_stamp=$(expr $time_stamp - $second_str)
                real_power_on_time=$(date -d @$power_on_time_stamp +"%Y-%m-%d %H:%M:%S")
                sed -i "/* HW reset cause:/a* Request date: $real_power_on_time" $RDK_RESET_INFO_LOG
                touch /tmp/record_power_on_time
                
                lastRebootReason="$(syscfg get X_RDKCENTRAL-COM_LastRebootReason)"
                new_lastRebootReason="$lastRebootReason,$real_power_on_time"
                len=$(expr length "$new_lastRebootReason")
                if [ $len -le 64 ]; then
                    syscfg set X_RDKCENTRAL-COM_LastRebootReason "$new_lastRebootReason"
                fi
            fi
        fi		
    fi
fi

