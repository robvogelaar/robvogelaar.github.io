#!/bin/sh

MTD19_BLOCK_1="/nvram2/mtd_1.bin"
MTD19_BLOCK_2="/nvram2/mtd_2.bin"
MTD19_BLOCK_3="/nvram2/mtd_3.bin"
MTD19_BLOCK_4="/nvram2/mtd_4.bin"

#Dump the first good block from mtd19
backup_mtd(){

    nanddump   --skip-bad-blocks-to-start --bb=skipbad --length=262144 /dev/mtd19 -f "$MTD19_BLOCK_1"
    nanddump   --skip-bad-blocks-to-start --bb=skipbad --startaddress=0x40000 --length=262144 /dev/mtd19 -f "$MTD19_BLOCK_2"
    nanddump   --skip-bad-blocks-to-start --bb=skipbad --startaddress=0x80000 --length=262144 /dev/mtd19 -f "$MTD19_BLOCK_3"
    nanddump   --skip-bad-blocks-to-start --bb=skipbad --startaddress=0xc0000 --length=262144 /dev/mtd19 -f "$MTD19_BLOCK_4"

    if [ -f "$MTD19_BLOCK_1" ]; then
        echo "MTD backup DONE!"
    fi
}

# check if target file exist
if [ -f "$MTD19_BLOCK_1" ]; then
    echo "MTD backup found ..."
    exit 1
else
    echo "MTD backup START!"
    backup_mtd
fi
