# add a ddns watchdog trigger to be run daily
#!/bin/sh
sysevent set ddns-start

