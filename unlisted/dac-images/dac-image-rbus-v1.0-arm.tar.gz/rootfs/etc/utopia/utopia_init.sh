#!/bin/sh
##########################################################################
# If not stated otherwise in this file or this component's Licenses.txt
# file the following copyright and licenses apply:
#
# Copyright 2015 RDK Management
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
##########################################################################
#######################################################################
#   Copyright [2014] [Cisco Systems, Inc.]
# 
#   Licensed under the Apache License, Version 2.0 (the \"License\");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
# 
#       http://www.apache.org/licenses/LICENSE-2.0
# 
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an \"AS IS\" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#######################################################################

ls /tmp/pam_initialized* > /tmp/pam_init_status

source /etc/utopia/service.d/log_capture_path.sh
source /etc/utopia/service.d/utctx_helper.sh
source /etc/device.properties

dmesg -n 5

if [ -f /proc/P-UNIT/status ]
then
	echo_t "*******************************************************************"
	echo_t "*                                                                  "
	echo_t "[utopia][init] P-UNIT status"
	cat /proc/P-UNIT/status
	echo_t "*                                                                  "
	echo_t "*******************************************************************"
fi

echo_t "Starting log module.."
/usr/sbin/log_start.sh

cat /etc/dhcp_static_hosts > /var/tmp/dhcp_static_hosts
cat /etc/hosts > /var/tmp/hosts

mount --bind /var/tmp/dhcp_static_hosts /etc/dhcp_static_hosts
mount --bind /var/tmp/hosts /etc/hosts

BUTTON_THRESHOLD=15

FACTORY_RESET_REASON="false"
PUNIT_RESET_DURATION=0

changeFilePermissions() {
       if [ -e "$1" ]; then
               filepermission=$(stat -c %a "$1")
               if [ "$filepermission" -ne "$2" ]
               then
                       chmod "$2" "$1"
                       echo "[utopia][init] Modified File Permission to $2 for file - $1"
               fi
       else
               echo "[utopia][init] changeFilePermissions: file $1 doesn't exist"
       fi
}

CheckAndReCreateDB()
{
	NVRAMFullStatus=`df -h /nvram | grep "100%"`
	if [ -n "$NVRAMFullStatus" ]; then
		if [ -f "/rdklogger/rdkbLogMonitor.sh" ]
		then
			  #Remove Old backup files if there	
			  sh /rdklogger/rdkbLogMonitor.sh "remove_old_logbackup"		 

		  	  #Re-create syscfg create again
			  syscfg_create -f /tmp/syscfg.db
			  if [ $? != 0 ]; then
				  NVRAMFullStatus=`df -h /nvram | grep "100%"`
				  if [ -n "$NVRAMFullStatus" ]; then
					 echo_t "[utopia][init] NVRAM Full(100%) and below is the dump"
					 du -h /nvram 
					 ls -al /nvram	 
				  fi
			  fi 
		fi
	fi 
}

if [ -f /usr/rdk/migration-mng/migration-mng ]; then
	echo_t "[utopia][init] Starting migration manager"
	/usr/rdk/migration-mng/migration-mng
fi

echo_t "[utopia][init] Starting syscfg using file store (/nvram/syscfg.db)"

# remove syscfg tmp files from nvram during bootup
if ls /nvram/syscfg_tmp.db_* 1> /dev/null 2>&1; then
    echo_t "Removing syscfg_tmp.db_ files from /nvram"
    rm -f /nvram/syscfg_tmp.db_*
fi

if [ ! -e /nvram/bbhm_bak_cfg.xml ]; then
    echo_t "bbhm backup file is not available"
fi

if [ -f /nvram/syscfg.db ]; then

   if [ -f /nvram/bootconfig_custindex ]; then

      if [ -x /usr/bin/db_mig ]; then
         # Preserve value of db_migration_complete before resetting /nvram/syscfg.db
         DB_MIG_COMPLETE=$(grep "db_migration_complete" /nvram/syscfg.db | cut -d "=" -f2)
      fi

      # If Customer index is set via boot config then ignore /nvram/syscfg.db
      echo -n > /tmp/syscfg.db
   else
      cp /nvram/syscfg.db /tmp/syscfg.db
   fi

   syscfg_create -f /tmp/syscfg.db
   if [ $? != 0 ]; then
	   CheckAndReCreateDB
   fi

   if [ -f /nvram/bootconfig_custindex ]; then
      # Setting preserved value of db_migration_completed
      if [ -x /usr/bin/db_mig ] && [ "$DB_MIG_COMPLETE" = "true" ]; then
         echo_t "[utopia][init] dbmig = $DB_MIG_COMPLETE"
         syscfg set db_migration_completed $DB_MIG_COMPLETE
      fi
      # Ensure that syscfg has been written back to Flash before
      # CUSTOMER_BOOT_CONFIG_FILE is removed (see below) to avoid race if
      # power is lost after removing CUSTOMER_BOOT_CONFIG_FILE but before
      # syscfg data containing the new customer ID has been saved to Flash.
      syscfg commit
   fi

else
   echo_t "[utopia][init] /nvram/syscfg.db file is not available"
   echo -n > /tmp/syscfg.db
   echo -n > /nvram/syscfg.db
   syscfg_create -f /tmp/syscfg.db
   if [ $? != 0 ]; then
        CheckAndReCreateDB
   fi
   #>>zqiu
   echo_t "[utopia][init] need to reset wifi when /nvram/syscfg.db file is not available"
   syscfg set factory_reset w
   syscfg commit
   #<<zqiu
   touch /nvram/.apply_partner_defaults
   # Put value 204 into networkresponse.txt file so that
   # all LAN services start with a configuration which will
   # redirect everything to Gateway IP.
   # This value again will be modified from network_response.sh
   echo_t "[utopia][init] Echoing network response during Factory reset"
   echo 204 > /var/tmp/networkresponse.txt
fi

# Get the values of FactoryResetSSID's from the psm xml backup file
WIFI_FACTORY_RESET_SSID1=$(grep -ir '1.FactoryResetSSID' /nvram/bbhm_bak_cfg.xml | awk -F"[<>]" '{print $3}')
WIFI_FACTORY_RESET_SSID2=$(grep -ir '2.FactoryResetSSID' /nvram/bbhm_bak_cfg.xml | awk -F"[<>]" '{print $3}')

if [ -x /usr/bin/db_mig ]; then
   DB_MIG_COMPLETE=$(syscfg get db_migration_completed)
   echo_t "[utopia][init] db_mig = $DB_MIG_COMPLETE"
fi

# Read reset duration to check if the unit was rebooted by pressing the HW reset button
if cat /proc/P-UNIT/status | grep -q "Reset duration from shadow register"; then
   # Note: Only new P-UNIT firmwares and Linux drivers (>= 1.1.x) support this.
   PUNIT_RESET_DURATION=`cat /proc/P-UNIT/status|grep "Reset duration from shadow register"|awk -F '[ |\.]' '{ print $9 }'`
   # Clear the Reset duration from shadow register value
   # echo "1" > /proc/P-UNIT/clr_reset_duration_shadow
   touch /var/tmp/utopia_cleared_shadow_reg.txt
   clean_reset_duration;
elif cat /proc/P-UNIT/status | grep -q "Last reset duration"; then
   PUNIT_RESET_DURATION=`cat /proc/P-UNIT/status|grep "Last reset duration"|awk -F '[ |\.]' '{ print $7 }'`
else
   echo_t "[utopia][init] Cannot read the reset duration value from /proc/P-UNIT/status"
fi

# Set the factory reset key if it was pressed for longer than our threshold
if [ "$PUNIT_RESET_DURATION" -gt "$BUTTON_THRESHOLD" ]
then
   syscfg set factory_reset y
   syscfg commit
   BUTTON_FR="1"
   SYSCFG_FR_VAL="y"
else
   SYSCFG_FR_VAL="$(syscfg get factory_reset)"
fi

SYSCFG_LastRebootReason="$(syscfg get X_RDKCENTRAL-COM_LastRebootReason)"

if [ "$SYSCFG_FR_VAL" = "y" ]
then
   echo_t "[utopia][init] Performing factory reset"

   FACTORY_RESET_REASON="true"

   # Remove log file first because it need get log file path from syscfg
   /usr/sbin/log_handle.sh reset

   syscfg_destroy -f

   rm -f /nvram/bbhm_bak_cfg.xml \
         /nvram/bbhm_tmp_cfg.xml \
         /nvram/Blocklist_XB3.txt \
         /nvram/bootstrap.json \
         /nvram/device_profile.json \
         /nvram/dnsmasq.leases \
         /nvram/dnsmasq_servers.conf \
         /nvram/dnsmasq.vendorclass \
         /nvram/.FirmwareUpgradeEndTime \
         /nvram/.FirmwareUpgradeStartTime \
         /nvram/hotspot_blob \
         /nvram/hotspot.json \
         /nvram/.keys/* \
         /nvram/partners_defaults.json  \
         /nvram/reverted \
         /nvram/rfc.json \
         /nvram/server-AddrMgr.xml \
         /nvram/server-cache.xml \
         /nvram/server-CfgMgr.xml \
         /nvram/server-duid \
         /nvram/server-IfaceMgr.xml \
         /nvram/server-TransMgr.xml \
         /nvram/steering.json \
         /nvram/syscfg.db \
         /nvram/.t2persistentfolder/DCMresponse.txt \
         /nvram/TLVData.bin \
         /nvram/webconfig_db.bin \
         /opt/secure/Blocklist_file.txt \
         /opt/secure/RFC/.RFC_SSHWhiteList.list \
         /opt/secure/RFC/tr181store.json

   rm -rf /nvram/mwo

   if [ -f /etc/ONBOARD_LOGGING_ENABLE ]
   then
      rm -rf /nvram/.device_onboarded \
             /nvram/DISABLE_ONBOARD_LOGGING \
             /nvram2/onboardlogs
   fi

   touch /nvram/.apply_partner_defaults

   create_wifi_default

   echo_t "[utopia][init] Retarting syscfg using file store (/nvram/syscfg.db)"

   echo -n > /tmp/syscfg.db
   echo -n > /nvram/syscfg.db
   syscfg_create -f /tmp/syscfg.db
   if [ $? != 0 ]; then
      CheckAndReCreateDB
   fi

   # Put value 204 into networkresponse.txt file so that
   # all LAN services start with a configuration which will
   # redirect everything to Gateway IP.
   # This value again will be modified from network_response.sh
   echo_t "[utopia][init] Echoing network response during Factory reset"
   echo 204 > /var/tmp/networkresponse.txt

   # If db_migration_completed was true before then make that persistent across factory resets.
   if [ -x /usr/bin/db_mig ] && [ "$DB_MIG_COMPLETE" = "true" ]; then
      echo_t "[utopia][init] dbmig during Factory reset = $DB_MIG_COMPLETE"
      syscfg set db_migration_completed $DB_MIG_COMPLETE
      syscfg commit
   fi

elif [ "$SYSCFG_FR_VAL" = "w" ]; then
    echo_t "[utopia][init] Performing WiFi reset"
    create_wifi_default
    syscfg unset factory_reset
fi

# Set the wifi_factory_reset_ssid accordingly to the value fetched from the PSM backup file
if [ "$WIFI_FACTORY_RESET_SSID1" = "1" ] || [ "$WIFI_FACTORY_RESET_SSID2" = "1" ]; then
    syscfg set wifi_factory_reset_ssid 1
    syscfg commit
else
    syscfg set wifi_factory_reset_ssid 0
    syscfg commit
fi

#echo_t "[utopia][init] Cleaning up vendor nvram"
# /etc/utopia/service.d/nvram_cleanup.sh

# In case customer index and factory reset happens at the same time,
# syscfg_create is called for two times. So remove bootconfig_custindex file after that.
if [ -f /nvram/bootconfig_custindex ]; then
    # Remove /nvram/bootconfig_custindex file. Customer specific values are already added in syscfg.
    rm -f /nvram/bootconfig_custindex
fi

#CISCOXB3-6085:Removing current configuration from nvram as a part of PSM migration.
if [ -f /nvram/bbhm_cur_cfg.xml  ]; then
       mv /nvram/bbhm_cur_cfg.xml /tmp/bbhm_cur_cfg.xml
elif [ -f /nvram/bbhm_bak_cfg.xml  ]; then	
	cp -f /nvram/bbhm_bak_cfg.xml /tmp/bbhm_cur_cfg.xml
fi

if [ -f /usr/ccsp/psm/lg_bbhm_patch.sh ]
then
    /usr/ccsp/psm/lg_bbhm_patch.sh /tmp/bbhm_cur_cfg.xml
fi

if [ -s /nvram/dnsmasq.leases ] ; then
   cp -f /nvram/dnsmasq.leases /var/lib/misc/dnsmasq.leases
fi
if [ -s /nvram/dnsmasq.options ] ; then
   cp -f /nvram/dnsmasq.options /var/lib/misc/dnsmasq.options
fi

#echo_t "[utopia][init] Starting system logging"
#/etc/utopia/service.d/service_syslog.sh syslog-start

# update max number of msg in queue based on system maximum queue memory.
# This update will be used for presence detection feature.
MSG_SIZE_MAX=`cat /proc/sys/fs/mqueue/msgsize_max`
MSG_MAX_SYS=`ulimit -q`
TOT_MSG_MAX=50
if [ -z "$MSG_MAX_SYS" ]; then
echo "ulimit cmd not avail assign mq msg_max :$TOT_MSG_MAX"
else
TOT_MSG_MAX=$((MSG_MAX_SYS/MSG_SIZE_MAX))
echo "mq msg_max :$TOT_MSG_MAX"
fi

echo $TOT_MSG_MAX > /proc/sys/fs/mqueue/msg_max

echo_t "[utopia][init] Starting sysevent subsystem"
#syseventd --threads 18
syseventd

sleep 1
echo_t "[utopia][init] Setting any unset system values to default"
apply_system_defaults
changeFilePermissions /nvram/syscfg.db 400

echo "[utopia][init] SEC: Syscfg stored in /nvram/syscfg.db"

queries="lan_ipaddr lan_netmask ForwardSSH unit_activated lan_ifname cmdiag_ifname ecm_wan_ifname nat_udp_timeout nat_tcp_timeout nat_icmp_timeout lan_ethernet_physical_ifnames"
get_utctx_val "$queries"

# Log to check the DHCP range corruption after system defaults applied
echo_t "[utopia][init] lan_ipaddr = $SYSCFG_lan_ipaddr lan_netmask = $SYSCFG_lan_netmask"

if [ "$SYSCFG_ForwardSSH" = "true" ]
then
    echo "SSH: Forward SSH changed to enabled" >> /rdklogs/logs/FirewallDebug.txt
else
    echo "SSH: Forward SSH changed to disabled" >> /rdklogs/logs/FirewallDebug.txt
fi

# syscfg "unit_activated" is set from network_response.sh based on the return code received.
echo_t "[utopia][init] Value of unit_activated got is: $SYSCFG_unit_activated"
if [ "$SYSCFG_unit_activated" = "1" ]
then
    echo_t "[utopia][init] Echoing network response during Reboot"
    echo 204 > /var/tmp/networkresponse.txt
fi

echo_t "[utopia][init] Applying iptables settings"

#disable telnet / ssh ports
iptables -A INPUT -i "$SYSCFG_lan_ifname" -p tcp --dport 23 -j DROP
iptables -A INPUT -i "$SYSCFG_lan_ifname" -p tcp --dport 22 -j DROP
iptables -A INPUT -i "$SYSCFG_cmdiag_ifname" -p tcp --dport 23 -j DROP
iptables -A INPUT -i "$SYSCFG_cmdiag_ifname" -p tcp --dport 22 -j DROP

ip6tables -A INPUT -i "$SYSCFG_lan_ifname" -p tcp --dport 23 -j DROP
ip6tables -A INPUT -i "$SYSCFG_lan_ifname" -p tcp --dport 22 -j DROP
ip6tables -A INPUT -i "$SYSCFG_cmdiag_ifname" -p tcp --dport 23 -j DROP
ip6tables -A INPUT -i "$SYSCFG_cmdiag_ifname" -p tcp --dport 22 -j DROP

#protect from IPv6 NS flooding
ip6tables -t mangle -A PREROUTING -i "$SYSCFG_ecm_wan_ifname" -d ff00::/8 -p ipv6-icmp -m icmp6 --icmpv6-type 135 -j DROP
ip6tables -t mangle -A PREROUTING -i "$SYSCFG_wan_ifname" -d ff00::/8 -p ipv6-icmp -m icmp6 --icmpv6-type 135 -j DROP

echo 60 > /proc/sys/net/netfilter/nf_conntrack_generic_timeout
echo 120 > /proc/sys/net/netfilter/nf_conntrack_udp_timeout_stream
echo 240 > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_syn_sent
echo 240 > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_time_wait
echo 60 > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_close
echo 20 > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_close_wait
echo 400 > /proc/sys/net/netfilter/nf_conntrack_expect_max
echo 3000 > /proc/sys/net/core/netdev_budget_usecs
echo 1200 > /proc/sys/net/core/netdev_budget

if [ "$BOX_TYPE" = "MV1" ]; then
    echo 8192  > /proc/sys/net/netfilter/nf_conntrack_max
else
    echo 16384 > /proc/sys/net/netfilter/nf_conntrack_max
fi

echo $SYSCFG_nat_udp_timeout > /proc/sys/net/netfilter/nf_conntrack_udp_timeout
echo $SYSCFG_nat_tcp_timeout > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_established
echo $SYSCFG_nat_icmp_timeout > /proc/sys/net/netfilter/nf_conntrack_icmp_timeout

#/sbin/ulogd -c /etc/ulogd.conf -d

echo_t "[utopia][init] Processing registration"
# run all executables in the sysevent registration directory
# echo_t "[utopia][init] Running registration using /etc/utopia/registration.d"
execute_dir /etc/utopia/registration.d &
#init_inter_subsystem&

#start  ntpd server on ARM
NTP_CONF=/etc/ntp.conf
NTP_CONF_TMP=/tmp/ntp.conf
if [ "$BOX_TYPE" = "XB3" ]
then
	cp $NTP_CONF $NTP_CONF_TMP
	echo "interface ignore wildcard" >> $NTP_CONF_TMP
	echo "interface listen $ARM_INTERFACE_IP" >> $NTP_CONF_TMP
	ntpd -c $NTP_CONF_TMP
fi

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# Temp disable radius vlan for Mv1

if [ "$BOX_TYPE" != "MV1" ]
then

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

#--------Set up Radius vlan -------------------
vconfig add l2sd0 4090
if [ "$BOX_TYPE" = "XB3" ] || [ "$BOX_TYPE" = "MV1" ];then
	/etc/utopia/service.d/service_multinet_exec add_radius_vlan &
else
	/etc/utopia/service.d/service_multinet/handle_sw.sh addVlan 0 4090 sw_6 
fi
ifconfig l2sd0.4090 192.168.251.1 netmask 255.255.255.0 up
ip rule add from all iif l2sd0.4090 lookup erouter


# RDKB-15951 : Dedicated l2sd0 vlan for Mesh Bhaul
vconfig add l2sd0 1060
if [ "$BOX_TYPE" = "XB3" ] || [ "$BOX_TYPE" = "MV1" ];then
        /etc/utopia/service.d/service_multinet_exec add_meshbhaul_vlan &
else
        /etc/utopia/service.d/service_multinet/handle_sw.sh addVlan 0 1060 sw_6
fi
ifconfig l2sd0.1060 up
ip rule add from all iif l2sd0.1060 lookup erouter

# Add QinQ for pod ethernet backhaul traffic
brctl addbr br403
ifconfig br403 192.168.245.1 netmask 255.255.255.0 up
brctl addif br403 l2sd0.1060
ip rule add from all iif br403 lookup erouter

# Add a new bridge for ethernet bhaul delivery
brctl addbr brebhaul
ifconfig brebhaul 169.254.85.1 netmask 255.255.255.0 up

#--------Marvell LAN-side egress flood mitigation----------------
echo_t "88E6172: Do not egress flood unicast with unknown DA"
swctl -c 11 -p 5 -r 4 -b 0x007b

# Creating IOT VLAN on ARM
if [ "$BOX_TYPE" = "XB3" ] || [ "$BOX_TYPE" = "MV1" ];then
    /etc/utopia/service.d/service_multinet_exec add_IOT_vlan &
else
    /etc/utopia/service.d/service_multinet/handle_sw.sh addVlan 0 4090 sw_6
fi

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# Temp disable radius vlan for Mv1

fi

#--------MV1 Mesh Bhaul ----------------------------------------------

if [ "$BOX_TYPE" = "MV1" ];then
    /etc/utopia/service.d/service_multinet_exec create_mesh_vlan &
fi

# ------ Creating trunk port for ext switch ports of primary LAN --------------------
if [ "$BOX_TYPE" = "MV1" ]; then
    for l2switchPort in $SYSCFG_lan_ethernet_physical_ifnames
    do
        vconfig add ${l2switchPort%%.*} ${l2switchPort##*.}
        ip link set dev ${l2switchPort} up
    done
fi

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# Check and set factory-reset as reboot reason 
if [ "$FACTORY_RESET_REASON" = "true" ]; then
   if [ -f /nvram/.image_upgrade_and_FR_done ] && [ "$BOX_TYPE" = "VNTXER5" ]; then
       echo "[utopia][init] Detected last reboot reason as FirmwareDownloadAndFactoryReset"
       if [ -e "/usr/bin/onboarding_log" ]; then
           /usr/bin/onboarding_log "[utopia][init] Detected last reboot reason as FirmwareDownloadAndFactoryReset"
       fi
       syscfg set X_RDKCENTRAL-COM_LastRebootReason "FirmwareDownloadAndFactoryReset"
       syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
       rm -f /nvram/.image_upgrade_and_FR_done
   else
       echo_t "[utopia][init] Detected last reboot reason as factory-reset"
       if [ -e "/usr/bin/onboarding_log" ]; then
          /usr/bin/onboarding_log "[utopia][init] Detected last reboot reason as factory-reset"
       fi
       syscfg set X_RDKCENTRAL-COM_LastRebootReason "$SYSCFG_LastRebootReason"
       syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
   fi
else
   rebootReason="$SYSCFG_LastRebootReason"
   rebootCounter=`syscfg get X_RDKCENTRAL-COM_LastRebootCounter`
   echo_t "[utopia][init] X_RDKCENTRAL-COM_LastRebootReason ($rebootReason)"
   if [ "$rebootReason" = "factory-reset" ]; then
      echo_t "[utopia][init] Setting last reboot reason as unknown"
      syscfg set X_RDKCENTRAL-COM_LastRebootReason "unknown"
   fi

   # Check and set last reboot reason for Power-On Reset ( Broadcom specific )
   if [ -f /proc/device-tree/bolt/reset-list ]; then
      case $(cat /proc/device-tree/bolt/reset-list) in
         "power_on"|"main_chip_input,power_on"|"power_on,main_chip_input")
            syscfg set X_RDKCENTRAL-COM_LastRebootReason "HW or Power-On Reset"
            syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
            ;;
      esac
   fi

      if [ "`cat /proc/P-UNIT/status|grep "Last reset origin"|awk '{ print $9 }'`" == "RESET_ORIGIN_HW" ]; then
         syscfg set X_RDKCENTRAL-COM_LastRebootReason "HW or Power-On Reset"
         syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
	 if [ -e "/usr/bin/onboarding_log" ]; then
	     /usr/bin/onboarding_log "[utopia][init] Last reboot reason set as HW or Power-On Reset"
	 fi
#ifdef CISCO_XB3_PLATFORM_CHANGES
         ##Work around: RDKB3939-500: /nvram/RDKB3939-500_RebootNotByPwrOff file not created by utopia.service(atom side) in case of power off shut down
      elif ( [ "$MODEL_NUM" = "DPC3939" ] || [ "$MODEL_NUM" = "DPC3939B" ] ) && [ "`cat /proc/P-UNIT/status|grep "Last reset origin"|awk '{ print $9 }'`" == "RESET_ORIGIN_ATOM" ] && [ ! -f "/nvram/RDKB3939-500_RebootNotByPwrOff" ]; then
         syscfg set X_RDKCENTRAL-COM_LastRebootReason "HW or Power-On Reset"
         syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
	 if [ -e "/usr/bin/onboarding_log" ]; then
	     /usr/bin/onboarding_log "[utopia][init] Last reboot reason set as HW or Power-On Reset"
	 fi
##LastRebootReason is set as BBU-Reset if the file /nvram/reboot.txt is present
      elif [ -f "/nvram/reboot.txt" ]; then
      	if [ "$MODEL_NUM" = "DPC3939" ] || [ "$MODEL_NUM" = "DPC3941" ] ||[ "$MODEL_NUM" = "DPC3939B" ] || [ "$MODEL_NUM" = "DPC3941B" ]; then
         syscfg set X_RDKCENTRAL-COM_LastRebootReason "BBU-Reset"
         syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
         rm /nvram/reboot.txt
      	fi
	  #Last reboot reason set as "PCD-reboot"  if the file /nvram/pcd_reboot_reason.txt is present
      elif [ -f "/nvram/pcd_reboot_reason.txt" ]; then
#        if [ "$MODEL_NUM" = "DPC3939" ] || [ "$MODEL_NUM" = "DPC3941" ] ||[ "$MODEL_NUM" = "DPC3939B" ] || [ "$MODEL_NUM" = "DPC3941B" ]; then
         echo_t "[utopia][init] Setting last reboot reason as PCD-reboot"
         syscfg set X_RDKCENTRAL-COM_LastRebootReason "PCD-reboot"
         syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
         rm /nvram/pcd_reboot_reason.txt
#        fi
#endif
##LastRebootReason is set as DOCSIS_SNMP_REBOOT if the file /nvram/CISCO_DOCSIS_SNMP_REBOOT is present
      elif [ -f "/nvram/CISCO_DOCSIS_SNMP_REBOOT" ]; then
      	if [ "$MODEL_NUM" = "DPC3939" ] || [ "$MODEL_NUM" = "DPC3941" ] ||[ "$MODEL_NUM" = "DPC3939B" ] || [ "$MODEL_NUM" = "DPC3941B" ]; then
         syscfg set X_RDKCENTRAL-COM_LastRebootReason "DOCSIS_SNMP_REBOOT"
         syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
         rm /nvram/CISCO_DOCSIS_SNMP_REBOOT
      	fi
      else
         RESET_DURATION=`cat /proc/P-UNIT/status|grep "Last reset duration"|awk '{ print $7 }'`
         result=`echo "$RESET_DURATION $BUTTON_THRESHOLD"| awk '{if ($1 > 0 && $1 < $2) print $1}'`
         if [ -n "$result" ]; then
            syscfg set X_RDKCENTRAL-COM_LastRebootReason "pin-reset"
            syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
	    if [ -e "/usr/bin/onboarding_log" ]; then
	        /usr/bin/onboarding_log "[utopia][init] Last reboot reason set as pin-reset"
	    fi
         fi

#ifdef CISCO_XB3_PLATFORM_CHANGES
      	  if [ -e "/proc/P-UNIT/status" ]; then
	         Punit_status=`grep -i "Last reset origin" /proc/P-UNIT/status | awk '{print $9}'`
	         if [ "$Punit_status" = "RESET_ORIGIN_DOCSIS_WATCHDOG" ] && [ "$rebootReason" = "Software_upgrade" ] && [ "$rebootCounter" = "1" ] && [ -e "/nvram/reboot_due_to_sw_upgrade" ];then
                     echo_t "[utopia][init] Setting last reboot reason as Software_upgrade_Watchdog_Reboot"
                     syscfg set X_RDKCENTRAL-COM_LastRebootReason "Software_upgrade_Watchdog_Reboot"
                     syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
	         elif ( [ "$rebootCounter" = "0" ] ) && ( [ "$Punit_status" = "RESET_ORIGIN_ATOM_WATCHDOG" ] || [ "$Punit_status" = "RESET_ORIGIN_DOCSIS_WATCHDOG" ] || [ "$Punit_status" = "RESET_ORIGIN_ATOM" ] );then
	             syscfg set X_RDKCENTRAL-COM_LastRebootReason "$Punit_status"
	             syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
		     if [ -e "/usr/bin/onboarding_log" ]; then
		         /usr/bin/onboarding_log "[utopia][init] Last reboot reason set as $Punit_status"
		     fi
		fi
	         if [ "$BOX_TYPE" = "XB3" ] || [ "$BOX_TYPE" = "MV1" ];then
	             Punit_Reset_Reason=`grep -i "Last reset reason" /proc/P-UNIT/status | awk '{print $9}'`
	             if [ "$Punit_Reset_Reason" = "RESET_WARM" ] && [ "$Punit_status" = "RESET_ORIGIN_DOCSIS" ];then
	                   syscfg set X_RDKCENTRAL-COM_LastRebootReason "HOST-OOPS-REBOOT"
	                   syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
	             fi
	         fi
         fi
#endif
      fi
fi

if [ "$MODEL_NUM" = "DPC3939B" ] || [ "$MODEL_NUM" = "DPC3941B" ] || [ "$BOX_TYPE" = "MV1" ]; then
    if [ -f /nvram/restore_reboot ];then
	syscfg set X_RDKCENTRAL-COM_LastRebootReason "restore-reboot"
	syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"

        if [ -f /nvram/bbhm_cur_cfg.xml-temp ]; then
            ##Work around: TCCBR-4087 Restored saved configuration is not restoring wan Static IP.
            ##after untar the new bbhm current config is overrriden/corrupted at times.
            ##Hence we are storing a backup and replacing it to current config upon such cases
            a=`md5sum /nvram/bbhm_cur_cfg.xml-temp`
            a=$(echo "$a" | cut -f 1 -d " ")
            b=`md5sum /tmp/bbhm_cur_cfg.xml`
            b=$(echo "$b" | cut -f 1 -d " ")
            if [[ $a != "$b" ]]; then
               cp /nvram/bbhm_cur_cfg.xml-temp /tmp/bbhm_cur_cfg.xml
            fi
            rm -f /nvram/bbhm_cur_cfg.xml-temp
        fi
    fi
    rm -f /nvram/restore_reboot
    rm -f /nvram/bbhm_bak_cfg.xml.prev
    rm -f /nvram/syscfg.db.prev
fi

syscfg commit

#Printing the last reboot reason on device console
echo " Last Reboot Reason is $rebootReason" >> /dev/console

if [ "$BOX_TYPE" = "MV3" ]
then
	rebootCounter=$(syscfg get X_RDKCENTRAL-COM_LastRebootCounter)
	if [ "$rebootCounter" = "0" ]
	then
		rebootReason="unknown"
		syscfg set X_RDKCENTRAL-COM_LastRebootReason "$rebootReason"
	fi
	/usr/bin/logger -p local0.crit -t NETWORK "$(date +'%a %b %d %T %Y') CPE Reboot because of - $rebootReason"
fi

#ifdef CISCO_XB3_PLATFORM_CHANGES
## Remove after setting last reboot reason
if [ -f "/nvram/RDKB3939-500_RebootNotByPwrOff" ]; then
	rm /nvram/RDKB3939-500_RebootNotByPwrOff
fi
#endif 

if [ -f /usr/bin/rpcserver ]; then
    echo_t "[utopia][init] Starting rpcserver in arm"
    nice -n -10 /usr/bin/rpcserver &
fi

# Remove webconfig_db.bin on factory reset on XB3 platforms,CISCOXB3-6731
if [ "$FACTORY_RESET_REASON" = "true" ] && [ "$BOX_TYPE" = "XB3" ];then
    rpcclient2 "rm -f /nvram/webconfig_db.bin"
    rpcclient2 "rm -f /nvram/Blocklist_XB3.txt"
fi

#set ntp status as unsynchronized on bootup
syscfg set ntp_status 2

echo_t "[utopia][init] setting Multicast MAC before any switch configs"
/etc/utopia/service.d/service_multinet_exec set_multicast_mac &

if [ "$MODEL_NUM" = "DPC3939B" ] || [ "$MODEL_NUM" = "DPC3941B" ]; then
	echo_t "[utopia][init] started dropbear process"
	/etc/utopia/service.d/service_sshd.sh sshd-start &
fi

# Create a psm default file which contains customer-specific values
/usr/bin/psm_defaults_create

# If Customer index changed then remove psm db from nvram
SYSCFG_CUST_CHANGED="$(syscfg get customer-index-changed)"
if [ "${SYSCFG_CUST_CHANGED}" = "true" ]; then
    echo_t "[utopia][init] removing bbhm_bak_cfg.xml during customer-index-changed scenario"
    rm -f /tmp/bbhm_cur_cfg.xml /nvram/bbhm_bak_cfg.xml
    syscfg unset customer-index-changed
    syscfg commit
fi

REBOOT_REASON_FILE="/nvram/reboot_reason"

if [ -x /usr/bin/db_mig ] && [ "$DB_MIG_COMPLETE" != "true" ]; then
    echo_t "[utopia][init] Running db_mig utility"
    /usr/bin/db_mig
    syscfg set db_migration_completed true
    syscfg set X_RDKCENTRAL-COM_LastRebootReason "Software_upgrade_from_legacy"
    syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
    syscfg commit
    rm -f $REBOOT_REASON_FILE

elif [ -e $REBOOT_REASON_FILE ]; then
    # Some platforms include a timestamp in the reboot reason file, e.g. "[%Y-%m-%dT%H:%M] <reason>"
    rebootReason=$(sed 's/\[.*\] //' < $REBOOT_REASON_FILE)
    echo_t "[utopia][init] Last reboot reason set as $rebootReason"
    syscfg set X_RDKCENTRAL-COM_LastRebootReason "$rebootReason"
    syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
    syscfg commit
    rm -f $REBOOT_REASON_FILE
fi

if [ "$BOX_TYPE" = "MV1" ]; then
    if [ -f /nvram/O/eventcode.dat ] && grep -qF "0 BOOTSTRAP" /nvram/O/eventcode.dat; then
        echo_t "[utopia][init] 0 BOOTSTRAP is already set"
    else
        echo "0 BOOTSTRAP||" >> /nvram/O/eventcode.dat
    fi
fi

#DHD Dongle crash check for Broadcom platforms
DHD_DONGLE_CRASH=/nvram/.dhd_dongle_crash
if [ -f "$DHD_DONGLE_CRASH" ]; then
	syscfg set X_RDKCENTRAL-COM_LastRebootReason "DHD Dongle Crash"
	syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
	syscfg commit
	rm /nvram/.dhd_dongle_crash
fi

# Kernel crash check for Broadcom platforms
BRCM_RESET_INFO=/tmp/brcm_reset_info.txt
if [ -f "$BRCM_RESET_INFO" ]; then
    BRCM_CRASH_DETECTED=$(cat $BRCM_RESET_INFO | grep -e "KERNEL_OOPS_DUMP" -e "Kernel crash detected: Yes")
    BRCM_CRASH_TPYPE=$(cat $BRCM_RESET_INFO | grep -e "Crash type:" | cut -f 2 -d ":" | sed 's/^ *//')
    BACKTRACE_FIRSTLINE=$(awk '/Backtrace:/{getline; print}' $BRCM_RESET_INFO)
    if [ -n "$(echo $BACKTRACE_FIRSTLINE | grep -e '\[\|\]')" ]; then
        BACKTRACE_FUNCTION=$(echo $BACKTRACE_FIRSTLINE | cut -d "+" -f1)
        module_1=${BACKTRACE_FIRSTLINE##*\[}
	    module_2=${module_1%%\]*}
    fi

    if [ -n "$BRCM_CRASH_DETECTED" ]; then
        if [ -n "$(echo $BRCM_CRASH_TPYPE | grep -e "Die")" ]; then
            if [ -n "$module_2" ]; then
                grep -q "fpm pool" "$BRCM_RESET_INFO"
                if [ $? -eq 0 ]; then
                    LastRebootReason_len=$(expr length "kernel-panic,Die-$module_2,$BACKTRACE_FUNCTION,FPM pool")
                    if [ $LastRebootReason_len -gt 64 ]; then
					    LastRebootReason_len=$(expr length "kernel-panic,Die-$module_2,$BACKTRACE_FUNCTION")
                        if [ $LastRebootReason_len -gt 64 ]; then
                            syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,Die-$module_2"
                        else
                            syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,Die-$module_2,$BACKTRACE_FUNCTION"
                        fi						
                    else
                        syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,Die-$module_2,$BACKTRACE_FUNCTION,FPM pool"
                    fi
                else
                    LastRebootReason_len=$(expr length "kernel-panic,Die-$module_2,$BACKTRACE_FUNCTION")
                    if [ $LastRebootReason_len -gt 64 ]; then
                        syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,Die-$module_2"
                    else
                        syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,Die-$module_2,$BACKTRACE_FUNCTION"
                    fi
                fi
            else
                syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,$BRCM_CRASH_TPYPE"
            fi			
        elif [ -n "$(echo $BRCM_CRASH_TPYPE | grep -e "RCU stall")" ]; then
            BRCM_RUNNER_CRASH_SUBTPYPE=$(cat $BRCM_RESET_INFO | grep -e "Ring:" -e "PhyRx Stats:")
            if [ -n "$BRCM_RUNNER_CRASH_SUBTPYPE" ]; then
                syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,RCU Stall-Runner"
            elif [ -n "$module_2" ]; then
                LastRebootReason_len=$(expr length "kernel-panic,RCU Stall-$module_2,$BACKTRACE_FUNCTION")
                if [ $LastRebootReason_len -gt 64 ]; then
                    syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,RCU Stall-$module_2"
                else
                    syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,RCU Stall-$module_2,$BACKTRACE_FUNCTION"
                fi				
            else
                syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,$BRCM_CRASH_TPYPE"
            fi
        else
            syscfg set X_RDKCENTRAL-COM_LastRebootReason "kernel-panic,$BRCM_CRASH_TPYPE"
        fi
        syscfg set X_RDKCENTRAL-COM_LastRebootCounter "1"
        syscfg commit
    fi
fi

#Fix if incorrect eth1 ethernet interface entry at instance 4
ETH1_INTF=$(syscfg get CosaEthIntIDs::eth1)
if [ "$ETH1_INTF" = "Interface4,4" ]; then
    syscfg unset CosaEthIntIDs::eth1
    syscfg unset CosaEthIntIDs::eth2
    syscfg unset CosaEthIntIDs::eth3
    syscfg commit
fi

if [ "`syscfg get CosaEthIntIDs::sw_1`" = "Interface1,1" ]; then
    syscfg unset CosaEthIntIDs::sw_1
    syscfg unset CosaEthIntIDs::sw_2
    syscfg unset CosaEthIntIDs::sw_3
    syscfg commit
fi

#LG-108:[CDRouter]TFTP session cannot through the router
#       0x00000001 - RSVP
#       0x00000002 - FTP
#       0x00000004 - TFTP
#       0x00000008 - Kerb88
#       0x00000010 - NetBios
#       0x00000020 - IKE
#       0x00000040 - RTSP
#       0x00000080 - Kerb1293
#       0x00000100 - H225
#       0x00000200 - PPTP
#       0x00000400 - MSN
#       0x00000800 - SIP
#       0x00001000 - ICQ
#       0x00002000 - IRC666x
#       0x00004000 - ICQTalk
#       0x00008000 - Net2Phone
#       0x00010000 - IRC7000
#       0x00020000 - IRC8000

AlgFTP=0x00000002
AlgTFTP=0x00000004
ALGRTSP=0x00000040
ALGPPTP=0x00000200
AlgSip=0x00000800

NatAlg=$(syscfg get NatAlgSupported)

if [ -z "$NatAlg" ]; then
    echo "NatAlg not supported" > /dev/console
elif [ $NatAlg -eq 0 ]; then
    echo 0 > /proc/sys/net/netfilter/nf_conntrack_helper
else
    echo 1 > /proc/sys/net/netfilter/nf_conntrack_helper

    kernel_release=$(uname -r)

    if [ $(( $NatAlg & $AlgFTP )) -eq 0 ]
    then
           echo "FTPAlg not supported" > /dev/console
    else
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_ftp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_ftp.ko
        fi
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_nat_ftp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_nat_ftp.ko
        fi
    fi

    if [ $(( $NatAlg & $AlgTFTP )) -eq 0 ]
    then
        echo "TFTPAlg not supported" > /dev/console
    else
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_tftp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_tftp.ko
        fi
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_nat_tftp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_nat_tftp.ko
        fi
    fi

    if [ $(( $NatAlg & $ALGRTSP )) -eq 0 ]
    then
        echo "RTSPAlg not supported" > /dev/console
    else
        if [ -f /lib/modules/${kernel_release}/kernel/drivers/bcm_media_gw/netfilter/nf_conntrack_rtsp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/drivers/bcm_media_gw/netfilter/nf_conntrack_rtsp.ko
        fi
        if [ -f /lib/modules/${kernel_release}/kernel/drivers/bcm_media_gw/netfilter/nf_nat_rtsp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/drivers/bcm_media_gw/netfilter/nf_nat_rtsp.ko
        fi
    fi

    if [ $(( $NatAlg & $ALGPPTP )) -eq 0 ]
    then
        echo "PPTPAlg not supported" > /dev/console
    else
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_proto_gre.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_proto_gre.ko
        fi
        if [ -f /lib/modules/${kernel_release}/kernel/net/ipv4/netfilter/nf_nat_proto_gre.ko  ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/ipv4/netfilter/nf_nat_proto_gre.ko
        fi
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_pptp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_pptp.ko
        fi
        if [ -f /lib/modules/${kernel_release}/kernel/net/ipv4/netfilter/nf_nat_pptp.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/ipv4/netfilter/nf_nat_pptp.ko
        fi
    fi

    if [ $(( $NatAlg & $AlgSip )) -eq 0 ]
    then
        echo "SipAlg not supported" > /dev/console
    else
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_sip.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_conntrack_sip.ko
        fi
        if [ -f /lib/modules/${kernel_release}/kernel/net/netfilter/nf_nat_sip.ko ]; then
            insmod /lib/modules/${kernel_release}/kernel/net/netfilter/nf_nat_sip.ko
        fi
    fi
fi

/etc/utopia/trueBridgeVirtNiHalSwitch.sh &

#MV2-7130
SYSCFG_FlashMonWriteLogLevel="$(syscfg get FlashMonWriteLogLevel)"
if [ "$SYSCFG_FlashMonWriteLogLevel" = "0" ]; then
	echo 0 > /proc/flash_stat_enable
elif [ "$SYSCFG_FlashMonWriteLogLevel" = "1" ]; then
	echo 1 > /proc/flash_stat_enable
fi

flash_ubi_num=$(mount | grep "on /nvram type ubifs" | awk -F ':' '{print $1}' | cut -b4)
if [ ! -z "$flash_ubi_num" ]; then
	echo "$flash_ubi_num" > /proc/flash_ubi_num
fi

#MV2-7130 END

/etc/utopia/sagemcom_update_resetinfo_time.sh &

echo "[utopia][init] completed creating utopia_inited flag"
touch /tmp/utopia_inited
