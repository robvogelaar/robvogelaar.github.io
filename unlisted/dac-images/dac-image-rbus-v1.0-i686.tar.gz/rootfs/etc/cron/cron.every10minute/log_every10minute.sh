#!/bin/sh
/usr/sbin/log_handle.sh
