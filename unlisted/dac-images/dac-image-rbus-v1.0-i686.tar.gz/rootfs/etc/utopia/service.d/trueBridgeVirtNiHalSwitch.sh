#!/bin/sh

echo "==========trueBridgeVirtNiHalSwitch.sh in========="

while true
do
	if [ -e /tmp/cm_initialized ]; then
		break
	fi
	echo "wait for cm initialized====="
	sleep 5
done

disable_virt_ni_hal()
{
	latticecli -n "set System.VirtNiHalEnable 0"
}

enable_virt_ni_hal()
{
	latticecli -n "set System.VirtNiHalEnable 1"
}

load_rtf()
{
	i=0
	wan_if=`syscfg get wan_physical_ifname`
	if [ $wan_if == "" ]; then
		echo "syscfg get wan_physical_ifname is empty, use erouter0 for wan interface for check bridge mode"
		wan_if="erouter0"
	fi	
	while true
	do
		echo "trueBridgeVirtNiHalSwitch [`date`] : load_rtf waitting for go into bridge mode..."
		brctl show brlan0 | grep -w $wan_if
		if [ $? -eq 0 ]; then
			echo "it is bridge mode!"
			break
		fi
		sleep 1
	done
	while true
	do
		echo "trueBridgeVirtNiHalSwitch [`date`] : load_rtf waitting for llan0 up, need to delete it..."
		i=`expr $i + 1`
		brctl show brlan0 | grep llan0
		if [ $? -eq 0 ]; then
			brctl delif brlan0 llan0
			break
		fi
		if [ $i -gt 30 ]; then
			break
		fi
		echo [`date`]wait llan0 $i time
		sleep 1
	done
	ip addr add 192.168.0.1 dev brlan0
	modprobe rtf
	echo host_inf brlan0 > /proc/driver/rtf/cmd
	echo brcmtag_opcode uc 1 > /proc/driver/dqnet/cmd
	echo enable 1 > /proc/driver/rtf/cmd
	echo e 0 > /proc/driver/ethsw/vlan
}

wait_for_bridge_mode_correct()
{
	i=0
	wan_if=`syscfg get wan_physical_ifname`
	if [ $wan_if == "" ]; then
		echo "syscfg get wan_physical_ifname is empty, use erouter0 for wan interface for check bridge mode"
		wan_if="erouter0"
	fi	
	
	if [ "$(syscfg get last_erouter_mode)" == "0" ]; then
		while true
		do
			echo "trueBridgeVirtNiHalSwitch [`date`] : waitting for go into bridge mode..."	
			brctl show brlan0 | grep -w $wan_if
			if [ $? -eq 0 ]; then
				echo "it is bridge mode!"
				break
			fi
			i=`expr $i + 1`
			if [ $i -gt 30 ]; then
				break
			fi					
			sleep 1
		done
	else
		while true
		do
			echo "trueBridgeVirtNiHalSwitch [`date`] : waitting for go into router mode..."	
			brctl show brlan0 | grep -w $wan_if
			if [ $? -ne 0 ]; then
				echo "it is router mode!"
				break
			fi
			i=`expr $i + 1`
			if [ $i -gt 30 ]; then
				break
			fi					
			sleep 1
		done	
	fi	
}
#sleep for boot read erouter mode from boot configure file correct
sleep 5
wait_for_bridge_mode_correct

if [ "$(syscfg get true_bridge_virtnihal_enable)" == "0" ]; then
	echo "disable virtNiHalMode!!!"
	disable_virt_ni_hal
else
	echo "enable virtNiHalMode!!!"
	enable_virt_ni_hal
	if [ ! -e /tmp/trueBridge_virtNiHal_initialized ]; then
		touch /tmp/trueBridge_virtNiHal_initialized
		# only call it one time
		load_rtf
	fi
fi

