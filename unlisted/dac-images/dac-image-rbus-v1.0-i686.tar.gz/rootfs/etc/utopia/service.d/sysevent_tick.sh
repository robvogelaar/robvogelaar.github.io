#!/bin/sh
sysevent set cron_every_minute
