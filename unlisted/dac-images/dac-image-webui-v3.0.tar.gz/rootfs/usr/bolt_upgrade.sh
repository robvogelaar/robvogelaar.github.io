#!/bin/sh
MT0_DUMP_FILE="/usr/mtd0.bin_dump"
MT1_DUMP_FILE="/usr/mtd1.bin_dump"
MT2_DUMP_FILE="/usr/mtd2.bin_dump"

# check the bolt version
CURRENT_BOLT_DATE=`cat /proc/device-tree/bolt/date`
TARGET_BOLT_DATE="2021-12-15 09:55:04"
TOO_EARLY_BOLT_DATE="2021-06-1 00:00:00"
# ISSUE_BOLT_DATE="2021-07-23 10:22:11"
# v5.03_v0.13_v0.3 # 2021-07-23 10:22:11
DATE_SIZE="19"

LOG_FILE="/tmp/mylog.log"
ERASE_ERROR_STR="MTD Erase failure"

echo "CURRENT_BOLT_DATE:"
echo ${CURRENT_BOLT_DATE}
echo "TARGET_BOLT_DATE:"
echo ${TARGET_BOLT_DATE}

# check register value
REG_value=`devmem 0xF04A2850 32`
if [ "$REG_value" = 0xC308001B ];then
	echo "reg value is 0xC308001B, no need do upgrade!"
	exit 0
else
	echo "reg value is 0xC3080020"
fi


# check if bolt date valid
if [ "${#CURRENT_BOLT_DATE}" != "$DATE_SIZE" ]; then
	echo "Error: CURRENT_BOLT_DATE string long is not 19, get current bolt build date failed!!"
	exit 1
fi

# check bolt date is earlier than 2021-June
too_early_bolt_date=`date -d "$TOO_EARLY_BOLT_DATE" +%s`
current_bolt_date=`date -d "$CURRENT_BOLT_DATE" +%s`

if [ $too_early_bolt_date -gt $current_bolt_date ]; then
    echo "$TOO_EARLY_BOLT_DATE > $CURRENT_BOLT_DATE"
    echo "current bolt date earlier than June 2021, no need do upgrade!"
    exit 0;
elif [ $too_early_bolt_date -eq $current_bolt_date ]; then
    echo "$TOO_EARLY_BOLT_DATE == $CURRENT_BOLT_DATE"
else
    echo "$TOO_EARLY_BOLT_DATE < $CURRENT_BOLT_DATE"
fi


if [ "$CURRENT_BOLT_DATE" = "$TARGET_BOLT_DATE" ];then
	echo "bolt already the one we need, no need do upgrade!"
	exit 0
fi

#if [ "$CURRENT_BOLT_DATE" == "$ISSUE_BOLT_DATE" ];then
#	echo "this is a issue version of bolt, need do upgrade!"
#else
#	echo "no need do upgrade!"
#	exit 0
#fi

# check if target file exist
if [ -f "$MT0_DUMP_FILE" ]; then
	echo "$MT0_DUMP_FILE found"
else 
	echo "Error: $MT0_DUMP_FILE does not exist!"
	exit 1
fi

if [ -f "$MT1_DUMP_FILE" ]; then
	echo "$MT1_DUMP_FILE found"
else 
	echo "Error: $MT1_DUMP_FILE does not exist!"
	exit 1
fi

if [ -f "$MT2_DUMP_FILE" ]; then
	echo "$MT2_DUMP_FILE found"
else 
	echo "Error: $MT2_DUMP_FILE does not exist!"
	exit 1
fi


# function define
upgrade_mtd0(){
	flash_erase /dev/mtd0 -N 0 0  2>&1 | tee ${LOG_FILE}
	if [ `grep -c "$ERASE_ERROR_STR" $LOG_FILE` -ne '0' ];then
		echo "Error: MTD0 Erase failure!"
		exit 1
	else
		echo "write to MTD0"
		nandwrite -n -o  /dev/mtd0 ${MT0_DUMP_FILE}
	fi
}

upgrade_mtd1(){
	flash_erase /dev/mtd1 -N 0 0  2>&1 | tee ${LOG_FILE}
	if [ `grep -c "$ERASE_ERROR_STR" $LOG_FILE` -ne '0' ];then
		echo "Error: MTD1 Erase failure!"
		exit 1
	else
		echo "write to MTD1"
		nandwrite -n -o  /dev/mtd1 ${MT1_DUMP_FILE}
	fi
}

upgrade_mtd2(){
	flash_erase /dev/mtd2 -N 0 0  2>&1 | tee ${LOG_FILE}
	if [ `grep -c "$ERASE_ERROR_STR" $LOG_FILE` -ne '0' ];then
		echo "Error: MTD2 Erase failure!"
		exit 1
	else
		echo "write to MTD2"
		nandwrite -n -o  /dev/mtd2 ${MT2_DUMP_FILE}
	fi
}


# do upgrade
upgrade_mtd0

upgrade_mtd1

upgrade_mtd2

echo "reboot!"
devmem 0xF0404304 32 1;devmem 0xF0404308 32 1
#echo b > /proc/sysrq-trigger 
#reboot


