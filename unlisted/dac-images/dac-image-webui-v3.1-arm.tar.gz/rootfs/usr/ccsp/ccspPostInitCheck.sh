#!/bin/sh

if [ $# -ne 3 ]; then
    echo "* Error: invalid parameters, please check"
    echo "*   Usage: $0 <process_name> <complete_indicator_filename> <timeout_in_sec>"
    echo "*   for example, $0 CcspCrSsp /tmp/cr_initialized 60"
    exit 1
fi

PROCESS_NAME="$1"
COMPLETION_INDICATOR="$2"
MAX_TIMEOUT="$3"

index=0
while [ $index -lt $MAX_TIMEOUT ]
do
    if [ -e "$COMPLETION_INDICATOR" ]; then
        echo "$PROCESS_NAME is ready ... $index elapsed"
        exit 0
    fi
    #echo "$PROCESS_NAME is not ready yet ... $index"
    index=$((index+1))
    sleep 1
done

echo "$PROCESS_NAME init failed, not ready until $index secs"
FAILUIRE_REPORT=ccsp_init_fail.$PROCESS_NAME.$(date "+%Y_%m_%d-%H_%M_%S")
#touch /nvram/$FAILUIRE_REPORT
touch /tmp/$FAILUIRE_REPORT
echo $FAILUIRE_REPORT >> /rdklogs/logs/ccsp_init_failure.log

echo "Killing $PROCESS_NAME"
killall $PROCESS_NAME
exit 1
